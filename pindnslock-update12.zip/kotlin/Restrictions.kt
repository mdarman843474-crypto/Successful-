package com.pindnslock

import android.content.Context
import android.os.UserManager

/**
 * Device Owner restrictions ke set: kaun si rok kab lagti aur kab hat'ti hai.
 *  - ON_LOCK: "DNS lock" ke saath lagti hain, "10 minute unlock" me hat'ti hain (Private DNS badalna).
 *  - ALWAYS : jab tak app Device Owner hai tab tak lagi rehti hain,
 *             sirf "Device Owner hatao" se hat'ti hain (factory reset).
 * Dusre APK ka install ab kisi rok se nahi rukta. Sirf PIN DNS Lock ka apna update rokte hain (InstallerPage + PageBlockService).
 */
object Restrictions {
    class Rule(val key: String, val label: String)

    val DNS = Rule(UserManager.DISALLOW_CONFIG_PRIVATE_DNS, "Private DNS")
    val RESET = Rule(UserManager.DISALLOW_FACTORY_RESET, "factory reset")

    /** Purane versions ne sab APK ka install band kar diya tha. Ye ab kabhi nahi lagti, bas hatayi jati hai. */
    private val LEGACY_INSTALL = Rule(UserManager.DISALLOW_INSTALL_UNKNOWN_SOURCES, "APK install")

    val ON_LOCK: List<Rule> = listOf(DNS)
    val ALWAYS: List<Rule> = listOf(RESET)
    val ALL: List<Rule> = ON_LOCK + ALWAYS

    fun isSet(c: Context, rule: Rule): Boolean =
        c.getSystemService(UserManager::class.java).hasUserRestriction(rule.key)

    /** Kabhi exception nahi fenkta: jo na lage wo missing() me dikhega. */
    fun add(c: Context, rules: List<Rule>) {
        val d = Admin.dpm(c)
        val a = Admin.component(c)
        for (r in rules) runCatching { d.addUserRestriction(a, r.key) }
    }

    /** Kabhi exception nahi fenkta: jo na hate wo active() me dikhega. */
    fun clear(c: Context, rules: List<Rule>) {
        val d = Admin.dpm(c)
        val a = Admin.component(c)
        for (r in rules) runCatching { d.clearUserRestriction(a, r.key) }
    }

    /** Purane version ki APK install wali rok hatao (sirf Device Owner ho tab asar karta hai). */
    fun clearLegacy(c: Context) {
        clear(c, listOf(LEGACY_INSTALL))
    }

    /** Inme se jo abhi nahi lagi (khali list = sab lagi hain). */
    fun missing(c: Context, rules: List<Rule>): List<Rule> = rules.filter { !isSet(c, it) }

    /** Inme se jo abhi lagi hain (khali list = sab hati hui hain). */
    fun active(c: Context, rules: List<Rule>): List<Rule> = rules.filter { isSet(c, it) }
}
