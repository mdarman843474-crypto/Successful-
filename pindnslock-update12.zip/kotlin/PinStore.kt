package com.pindnslock

import android.content.Context
import android.util.Base64
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

sealed class PinResult {
    object Ok : PinResult()
    data class Wrong(val attemptsLeft: Int) : PinResult()
    data class Locked(val seconds: Long) : PinResult()
}

/** Naya PIN set / change karte waqt kya galat hai. */
enum class PinIssue { BAD_LENGTH, TOO_SIMPLE, MISMATCH, OLD_BAD_LENGTH, SAME_AS_OLD }

/** 12-digit PIN: salted PBKDF2 hash + lockout after repeated wrong attempts. */
object PinStore {
    private const val MAX_FAILS = 5
    private fun prefs(c: Context) = c.getSharedPreferences("pin_store", Context.MODE_PRIVATE)

    fun isValidFormat(pin: String) = pin.length == 12 && pin.all { it in '0'..'9' }

    /** Naya PIN set karne ke niyam. null = sab theek. */
    fun checkNew(pin: String, confirm: String): PinIssue? = when {
        !isValidFormat(pin) -> PinIssue.BAD_LENGTH
        pin.toSet().size < 3 -> PinIssue.TOO_SIMPLE
        pin != confirm -> PinIssue.MISMATCH
        else -> null
    }

    /** PIN badalne ke niyam: purana PIN theek format me, naya PIN niyam me aur purane se alag. null = sab theek. */
    fun checkChange(oldPin: String, pin: String, confirm: String): PinIssue? {
        if (!isValidFormat(oldPin)) return PinIssue.OLD_BAD_LENGTH
        val issue = checkNew(pin, confirm)
        if (issue != null) return issue
        if (pin == oldPin) return PinIssue.SAME_AS_OLD
        return null
    }

    fun isSet(c: Context) = prefs(c).contains("hash")

    fun set(c: Context, pin: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        prefs(c).edit()
            .putString("salt", Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString("hash", Base64.encodeToString(hash(pin, salt), Base64.NO_WRAP))
            .putInt("fails", 0)
            .putLong("lockUntil", 0L)
            .apply()
    }

    /** Slow (PBKDF2 do baar) - background thread se chalao. Purana PIN sahi ho tabhi naya set hota hai. */
    fun change(c: Context, oldPin: String, newPin: String): PinResult {
        val r = verify(c, oldPin)
        if (r is PinResult.Ok) set(c, newPin)
        return r
    }

    /** Slow (PBKDF2) - call from a background thread. */
    fun verify(c: Context, pin: String): PinResult {
        val p = prefs(c)
        val now = System.currentTimeMillis()
        val lockUntil = p.getLong("lockUntil", 0L)
        if (now < lockUntil) return PinResult.Locked((lockUntil - now) / 1000 + 1)

        val salt = Base64.decode(p.getString("salt", "") ?: "", Base64.NO_WRAP)
        val expected = Base64.decode(p.getString("hash", "") ?: "", Base64.NO_WRAP)
        if (MessageDigest.isEqual(hash(pin, salt), expected)) {
            p.edit().putInt("fails", 0).apply()
            return PinResult.Ok
        }

        val fails = p.getInt("fails", 0) + 1
        if (fails % MAX_FAILS == 0) {
            val level = fails / MAX_FAILS                       // 1, 2, 3 ...
            val waitMs = 60_000L * (1L shl minOf(level - 1, 6)) // 1, 2, 4 ... 64 min
            p.edit().putInt("fails", fails).putLong("lockUntil", now + waitMs).apply()
            return PinResult.Locked(waitMs / 1000)
        }
        p.edit().putInt("fails", fails).apply()
        return PinResult.Wrong(MAX_FAILS - fails % MAX_FAILS)
    }

    private fun hash(pin: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(pin.toCharArray(), salt, 100_000, 256)
        return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
    }
}
