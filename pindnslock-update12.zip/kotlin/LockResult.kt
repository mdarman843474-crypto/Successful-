package com.pindnslock

/**
 * DnsLock ke kaam ka natija. Isme screen ka koi text nahi hota,
 * text Messages.kt banata hai.
 */
sealed class LockResult {

    /** Kaam ho gaya. checkSkipped = Android ka host check fail hua tha, Settings wala host hi lock kiya. */
    data class Ok(val checkSkipped: Boolean = false) : LockResult()

    /** Kaam nahi hua. detail me wajah ka chhota extra (jaise Android ki abhi ki DNS state). */
    data class Fail(val reason: Reason, val detail: String = "") : LockResult()

    enum class Reason {
        NOT_OWNER,
        BAD_HOST,
        HOST_NOT_SERVING,
        SET_FAILED,
        DNS_MISMATCH,
        VERIFY_FAILED,
        RELOCK_NOT_SCHEDULED,
        STILL_LOCKED,
        STILL_OWNER
    }
}
