package com.pindnslock

/**
 * Android is app ko background me chalne dega ya nahi (Private DNS ki nigrani ke liye zaroori).
 * Android ise lock karne nahi deta, isliye app sirf dikhati hai.
 */
enum class BatteryState { OK, OPTIMIZED, RESTRICTED }

/** Private DNS page rokne wali Accessibility service ka haal. */
enum class PageBlockState { OFF, ENABLED_NOT_RUNNING, RUNNING }

/** Screen ke status box ke liye system ki ek jhalak. */
data class DeviceStatus(
    val owner: Boolean,
    val dns: String,
    val locked: Boolean,
    val unlockUntil: Long,
    val updateLocked: Boolean,
    val updateUntil: Long,
    val resetBlocked: Boolean,
    val guardOn: Boolean,
    val fastGuard: Boolean,
    val directWrite: Boolean,
    val pageBlock: PageBlockState,
    val appLocked: Boolean,
    val battery: BatteryState
)
