package com.pindnslock

import android.content.Context

/** Sirf yaad rakhne wala hissa: chuna hua host aur unlock ka wakt (SharedPreferences). */
object LockStore {
    const val DEFAULT_HOST = "dns.adguard-dns.com"

    private fun prefs(c: Context) = c.getSharedPreferences("dns_state", Context.MODE_PRIVATE)

    fun savedHost(c: Context): String = prefs(c).getString("host", DEFAULT_HOST) ?: DEFAULT_HOST

    fun unlockUntil(c: Context): Long = prefs(c).getLong("unlockUntil", 0L)

    fun saveLocked(c: Context, host: String) {
        prefs(c).edit().putString("host", host).putLong("unlockUntil", 0L).apply()
    }

    fun setUnlockUntil(c: Context, millis: Long) {
        prefs(c).edit().putLong("unlockUntil", millis).apply()
    }

    fun clearUnlock(c: Context) {
        setUnlockUntil(c, 0L)
    }

    /** PIN DNS Lock ka update karne ki 10 minute wali khidki ka end time (0 = band). */
    fun updateUntil(c: Context): Long = prefs(c).getLong("updateUntil", 0L)

    fun updateOpen(c: Context): Boolean = updateUntil(c) > System.currentTimeMillis()

    fun setUpdateUntil(c: Context, millis: Long) {
        prefs(c).edit().putLong("updateUntil", millis).apply()
    }

    fun clearUpdateWindow(c: Context) {
        setUpdateUntil(c, 0L)
    }
}
