package com.pindnslock

import android.content.Context
import java.text.DateFormat
import java.util.Date

/** Accessibility service ka chhota debug record. Status box ko dabake rakhne par clipboard me copy hota hai. */
object PageBlockLog {
    private const val PREFS = "page_block_log"

    @Volatile
    private var events = 0

    @Volatile
    private var lastSnapshotAt = 0L

    private fun prefs(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun countEvent() {
        events++
    }

    fun connected(c: Context) {
        prefs(c).edit().putLong("connectedAt", System.currentTimeMillis()).apply()
    }

    fun blocked(c: Context) {
        val p = prefs(c)
        p.edit().putInt("blocks", p.getInt("blocks", 0) + 1).putLong("blockedAt", System.currentTimeMillis()).apply()
    }

    fun error(c: Context, e: Throwable) {
        prefs(c).edit().putString("error", e.toString()).apply()
    }

    /** Snapshot ka time aaya? (1 second me ek hi baar, taaki har event par poora tree na padhna pade) */
    fun snapshotDue(): Boolean = System.currentTimeMillis() - lastSnapshotAt >= 1000L

    /** Settings ki wo window jisme "Private DNS" likha ho: kya dikha aur page pehchana gaya ya nahi. */
    fun snapshot(c: Context, text: String) {
        val now = System.currentTimeMillis()
        lastSnapshotAt = now
        prefs(c).edit().putString("snapshot", text).putLong("snapshotAt", now).apply()
    }

    fun dump(c: Context): String {
        val p = prefs(c)
        val fmt = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.MEDIUM)
        fun at(key: String): String {
            val t = p.getLong(key, 0L)
            return if (t == 0L) "kabhi nahi" else fmt.format(Date(t))
        }
        val sb = StringBuilder()
        sb.append("PIN DNS Lock debug\n")
        sb.append("owner=").append(DnsState.isOwner(c)).append(" locked=").append(DnsState.isLocked(c)).append('\n')
        sb.append("page block: ").append(PageBlock.state(c))
            .append(" | WRITE_SECURE_SETTINGS=").append(DnsWriter.canWriteDirect(c)).append('\n')
        sb.append("service last connected: ").append(at("connectedAt")).append('\n')
        sb.append("events (is process me): ").append(events)
            .append(" | blocks: ").append(p.getInt("blocks", 0))
            .append(" (last ").append(at("blockedAt")).append(")\n")
        sb.append("last error: ").append(p.getString("error", "none")).append('\n')
        sb.append("--- last relevant window (Settings / installer) (").append(at("snapshotAt")).append(") ---\n")
        sb.append(p.getString("snapshot", "none"))
        return sb.toString()
    }
}
