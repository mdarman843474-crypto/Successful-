package com.pindnslock

import android.app.admin.DevicePolicyManager
import android.content.Context
import android.content.pm.PackageManager
import android.provider.Settings

/**
 * Private DNS ko host par set karne ke do tareeke:
 *  1) Device Owner API (setGlobalPrivateDnsModeSpecifiedHost). Android pehle host ka DNS-over-TLS check karta hai,
 *     aur kuch networks par ye check fail ho jata hai (jabki DNS chal raha hota hai).
 *  2) Seedha Settings me likhna. Iske liye WRITE_SECURE_SETTINGS permission chahiye, jo adb se ek baar milti hai:
 *     pm grant com.pindnslock android.permission.WRITE_SECURE_SETTINGS
 */
object DnsWriter {
    private const val PERMISSION = "android.permission.WRITE_SECURE_SETTINGS"

    /** code = DevicePolicyManager.PRIVATE_DNS_SET_*, direct = Android ka host check chhod ke seedha likha gaya. */
    class HostSet(val code: Int, val direct: Boolean)

    /** adb se permission mil chuki hai? */
    fun canWriteDirect(c: Context): Boolean =
        c.checkSelfPermission(PERMISSION) == PackageManager.PERMISSION_GRANTED

    /** Blocking (Android ka host check network karta hai) - background thread se chalao. */
    fun setHost(c: Context, host: String): HostSet {
        val d = Admin.dpm(c)
        val a = Admin.component(c)

        var r = d.setGlobalPrivateDnsModeSpecifiedHost(a, host)
        if (r == DevicePolicyManager.PRIVATE_DNS_SET_ERROR_HOST_NOT_SERVING) {
            r = d.setGlobalPrivateDnsModeSpecifiedHost(a, host) // check kabhi kabhi timeout ho jata hai: ek baar aur
        }
        if (r == DevicePolicyManager.PRIVATE_DNS_SET_NO_ERROR) return HostSet(r, false)

        // Android ka check fail hua: permission mili ho to check chhod ke seedha likho
        if (!canWriteDirect(c)) return HostSet(r, false)
        val wrote = runCatching {
            val cr = c.contentResolver
            Settings.Global.putString(cr, "private_dns_specifier", host) &&
                Settings.Global.putString(cr, "private_dns_mode", "hostname")
        }.getOrDefault(false)
        return if (wrote && DnsState.isHostActive(c, host)) {
            HostSet(DevicePolicyManager.PRIVATE_DNS_SET_NO_ERROR, true)
        } else {
            HostSet(r, false)
        }
    }
}
