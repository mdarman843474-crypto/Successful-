package com.pindnslock

import android.view.accessibility.AccessibilityNodeInfo

/**
 * Settings ka "Factory reset" page pehchanna (sirf English Settings).
 * Xiaomi ke page par heading "Erase the following items" aur neeche laal button "Erase all data" hota hai.
 */
object FactoryResetPage {
    fun isShownIn(root: AccessibilityNodeInfo): Boolean {
        // Tez filter: is page par "Erase the following items" likha hota hai
        if (root.findAccessibilityNodeInfosByText("Erase the following items").isNullOrEmpty()) return false
        if (PageText.isSearchScreen(root)) return false
        return PageText.hasExact(root, "Erase the following items") && PageText.hasExact(root, "Erase all data")
    }

    /** Debug ke liye: kaun si sharten sach thin. */
    fun verdict(root: AccessibilityNodeInfo): String {
        val heading = !root.findAccessibilityNodeInfosByText("Erase the following items").isNullOrEmpty()
        return "heading=" + heading + " search=" + PageText.isSearchScreen(root) +
            " exactHeading=" + PageText.hasExact(root, "Erase the following items") +
            " exactButton=" + PageText.hasExact(root, "Erase all data") + " => page=" + isShownIn(root)
    }
}
