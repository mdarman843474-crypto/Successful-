package com.pindnslock

import android.accessibilityservice.AccessibilityService
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast

/**
 * Ye screens khulte hi band kar deti hai (pehle Back, phir Home):
 *  - Settings me Private DNS page, search screen aur "Additional settings" page: jab DNS lock laga ho
 *    (unlock ke 10 minute me khulte hain)
 *  - Settings me Factory reset page: jab tak factory reset ki rok lagi hai
 *  - Package installer par PIN DNS Lock ka apna update: jab tak "update ke liye 10 minute" ki khidki band hai.
 *    Dusre apps ka installer screen kabhi nahi rukta.
 * Sirf Settings aur installer ke events dekhti hai (res/xml/accessibility_config.xml).
 * Koi bhi galti hone par crash nahi hoti (crash hone par Android "Not working" dikhata hai); galti PageBlockLog me jati hai.
 */
class PageBlockService : AccessibilityService() {
    private var lastActionAt = 0L
    private var attempts = 0

    override fun onServiceConnected() {
        super.onServiceConnected()
        PageBlockLog.connected(this)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        try {
            handle(event)
        } catch (e: Exception) {
            PageBlockLog.error(this, e)
        }
    }

    private fun handle(event: AccessibilityEvent?) {
        if (event == null) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg != SETTINGS_PACKAGE && pkg != SEARCH_PACKAGE && pkg !in INSTALLER_PACKAGES) return
        PageBlockLog.countEvent()
        val root = rootInActiveWindow ?: return

        // Debug: jis window me in pages ke nishan hon uska hisaab rakho (1 second me ek baar)
        if (PageBlockLog.snapshotDue()) snapshotIfRelevant(root, pkg)

        val message = when {
            pkg in INSTALLER_PACKAGES ->
                if (InstallerPage.isShownIn(root) && DnsState.isUpdateLocked(this))
                    "PIN DNS Lock ka update band hai: app me PIN se update ki khidki kholo"
                else return
            PrivateDnsPage.isShownIn(root) && DnsState.isLocked(this) -> "Private DNS band hai (PIN DNS Lock)"
            FactoryResetPage.isShownIn(root) && DnsState.isResetBlocked(this) -> "Factory reset band hai (PIN DNS Lock)"
            SettingsSearchPage.isShownIn(root) && DnsState.isLocked(this) -> "Settings search band hai (PIN DNS Lock)"
            AdditionalSettingsPage.isShownIn(root) && DnsState.isLocked(this) -> "Additional settings band hai (PIN DNS Lock)"
            else -> return
        }
        if (!DnsState.isOwner(this)) return
        block(message)
    }

    private fun snapshotIfRelevant(root: AccessibilityNodeInfo, pkg: String) {
        val verdict = when {
            pkg in INSTALLER_PACKAGES -> "installer(" + pkg + "): shown=" + InstallerPage.isShownIn(root)
            !root.findAccessibilityNodeInfosByText("Private DNS").isNullOrEmpty() -> "private dns: " + PrivateDnsPage.verdict(root)
            !root.findAccessibilityNodeInfosByText("Erase all data").isNullOrEmpty() -> "factory reset: " + FactoryResetPage.verdict(root)
            !root.findAccessibilityNodeInfosByText("Additional settings").isNullOrEmpty() -> "additional settings: " + AdditionalSettingsPage.verdict(root)
            PageText.hasEditText(root) && PageText.hasExact(root, "Cancel") -> "search: " + SettingsSearchPage.verdict(root)
            else -> return
        }
        PageBlockLog.snapshot(this, verdict + "\n" + PageText.describe(root))
    }

    override fun onInterrupt() {
        // kuch nahi
    }

    private fun block(message: String) {
        val now = SystemClock.elapsedRealtime()
        if (now - lastActionAt < MIN_GAP_MS) return
        attempts = if (now - lastActionAt > RESET_AFTER_MS) 1 else attempts + 1
        lastActionAt = now
        PageBlockLog.blocked(this)
        if (attempts == 1) {
            Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
        }
        // Pehle Back; page phir bhi na hate to Home
        performGlobalAction(if (attempts <= 2) GLOBAL_ACTION_BACK else GLOBAL_ACTION_HOME)
    }

    companion object {
        private const val SETTINGS_PACKAGE = "com.android.settings"
        private const val SEARCH_PACKAGE = "com.android.settings.intelligence"
        private val INSTALLER_PACKAGES = setOf(
            "com.google.android.packageinstaller",
            "com.android.packageinstaller",
            "com.miui.packageinstaller"
        )
        private const val MIN_GAP_MS = 400L
        private const val RESET_AFTER_MS = 4_000L
    }
}
