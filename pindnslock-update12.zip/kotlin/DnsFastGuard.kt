// DnsFastGuard.kt  -  PIN DNS Lock v1.3 ke liye patch (sample, build/test nahi kiya)
//
// Kya karta hai:
//   Abhi DnsGuard JobScheduler se chalta hai. Android us par kam se kam 500 ms ka
//   delay lagata hai, isliye hostname wapas aane me 1-5 second lagte hain.
//   Ye patch ek chalti hui service me ContentObserver lagata hai: private_dns_mode ya
//   private_dns_specifier badalte hi seedha DnsGuard.enforce() chalta hai, jo saved
//   host direct Settings.Global me wapas likh deta hai (WRITE_SECURE_SETTINGS se).
//   Andaza: lagbhag 20-100 millisecond. Picosecond Android me possible nahi hai.
//
// Kharcha / limit:
//   - Ek foreground service chalti hai, silent (IMPORTANCE_MIN) notification ke saath.
//   - Purana JobScheduler guard backup ke taur par waisa hi rehta hai.
//   - Hostname wapas aane tak ek chhota gap rahega. Use bilkul khatam sirf tab hoga jab
//     page khulne se hi rok diya jaye (accessibility page block).
//   - Settings page ka tick screen par refresh hone me alag se waqt lag sakta hai.
//   - Original source mere paas nahi tha. Naam APK ke bytecode se liye hain:
//     DnsGuard.enforce / ensureScheduled / runOnce / kick / cancel (sab public).
//   - HyperOS par battery "No restrictions" aur Autostart ON rakho.

package com.pindnslock

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.database.ContentObserver
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.provider.Settings

class DnsFastGuardService : Service() {

    private var thread: HandlerThread? = null
    private var observer: ContentObserver? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        if (!startAsForeground()) {
            // Foreground nahi ban paayi: service band, JobScheduler guard backup chalta rahega
            stopSelf()
            return
        }
        val t = HandlerThread("dns-fast-guard").also { it.start() }
        thread = t
        val handler = Handler(t.looper)

        val obs = object : ContentObserver(handler) {
            override fun onChange(selfChange: Boolean) {
                guard()
            }
        }
        observer = obs

        val cr = contentResolver
        cr.registerContentObserver(Settings.Global.getUriFor("private_dns_mode"), false, obs)
        cr.registerContentObserver(Settings.Global.getUriFor("private_dns_specifier"), false, obs)

        running = true

        // Service shuru hote hi ek baar check
        handler.post { guard() }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    // enforce() khud check karta hai: Device Owner ho, LOCKED ho, host alag ho to hi likhta hai.
    // Apni likhi hui value se dobara trigger hone par host match karta hai, to loop nahi banta.
    private fun guard() {
        try {
            DnsGuard.enforce(applicationContext)
        } catch (e: Throwable) {
            // koi error aaye to bhi observer zinda rahe
        }
    }

    override fun onDestroy() {
        running = false
        observer?.let { contentResolver.unregisterContentObserver(it) }
        observer = null
        thread?.quitSafely()
        thread = null
        super.onDestroy()
    }

    private fun startAsForeground(): Boolean {
        return try {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "DNS lock", NotificationManager.IMPORTANCE_MIN)
            )
            val n = Notification.Builder(this, CHANNEL)
                .setContentTitle("Private DNS lock chalu")
                .setSmallIcon(android.R.drawable.ic_lock_lock)
                .setOngoing(true)
                .build()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else {
                startForeground(NOTIF_ID, n)
            }
            true
        } catch (e: Throwable) {
            false
        }
    }

    companion object {
        /** Service abhi chal rahi hai? (status box ke liye) */
        @Volatile
        var running = false

        private const val CHANNEL = "dns_fast_guard"
        private const val NOTIF_ID = 4110

        fun start(ctx: Context) {
            try {
                ctx.startForegroundService(Intent(ctx, DnsFastGuardService::class.java))
            } catch (e: Throwable) {
                // Background se start nahi hui to JobScheduler guard backup rahega
            }
        }

        fun stop(ctx: Context) {
            try {
                ctx.stopService(Intent(ctx, DnsFastGuardService::class.java))
            } catch (e: Throwable) {
            }
        }
    }
}

/* ---------------------------------------------------------------------
   1) DnsGuard.kt me sirf ye 4 line jodo (har function ke end me)
   ---------------------------------------------------------------------

   fun ensureScheduled(ctx: Context) { ...; DnsFastGuardService.start(ctx) }
   fun runOnce(ctx: Context)         { ...; DnsFastGuardService.start(ctx) }  // finally ke baad
   fun kick(ctx: Context)            { ...; DnsFastGuardService.start(ctx) }
   fun cancel(ctx: Context)          { ...; DnsFastGuardService.stop(ctx) }   // Device Owner hatane par

   Matlab: lock par ya reboot ke baad job chalte hi service wapas shuru ho jati hai,
   aur "Device Owner hatao" dabane par band.

   ---------------------------------------------------------------------
   2) AndroidManifest.xml me jodo
   ---------------------------------------------------------------------

   <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
   <uses-permission android:name="android.permission.FOREGROUND_SERVICE_SPECIAL_USE" />
   <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />

   <service
       android:name=".DnsFastGuardService"
       android:exported="false"
       android:foregroundServiceType="specialUse">
       <property
           android:name="android.app.PROPERTY_SPECIAL_USE_FGS_SUBTYPE"
           android:value="Private DNS lock watcher" />
   </service>

   ---------------------------------------------------------------------
   3) Build ke baad
   ---------------------------------------------------------------------
   1. Purani wahi keystore se sign karo (alag keystore se update install nahi hoga).
   2. App me PIN daal kar "10 minute unlock", phir naya APK update karo.
   3. "DNS lock karo" dabao. Notification me "Private DNS lock chalu" dikhna chahiye.
   4. Private DNS me Off dabao: hostname lagbhag turant wapas aana chahiye.
      LADB: settings get global private_dns_mode  ->  hostname
   --------------------------------------------------------------------- */
