package com.pindnslock

import android.app.job.JobInfo
import android.app.job.JobScheduler
import android.content.ComponentName
import android.content.Context

/** Unlock window khatam hone par auto-relock ka job. */
object RelockScheduler {
    const val JOB_ID = 4101

    /** true = job schedule ho gaya. */
    fun schedule(c: Context, minutes: Int): Boolean {
        val ms = minutes * 60_000L
        return try {
            val info = JobInfo.Builder(JOB_ID, ComponentName(c, RelockJobService::class.java))
                .setMinimumLatency(ms)
                .setOverrideDeadline(ms + 60_000L)
                .setPersisted(true)
                .build()
            c.getSystemService(JobScheduler::class.java).schedule(info) == JobScheduler.RESULT_SUCCESS
        } catch (e: Exception) {
            false
        }
    }

    fun cancel(c: Context) {
        c.getSystemService(JobScheduler::class.java).cancel(JOB_ID)
    }
}
