package com.pindnslock

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

/**
 * Sirf screen: views dikhana aur buttons ko DnsLock / PinStore se jodna.
 * Logic aur text alag files me hain (DnsLock, PinStore, Messages).
 *
 * PIN gate: PIN set hone ke baad app kholne par pehle sirf PIN screen dikhti hai.
 * App se bahar jate hi (Home / recents / screen off) gate dobara lag jata hai.
 */
class MainActivity : Activity() {

    companion object {
        const val UNLOCK_MINUTES = 10
        const val UPDATE_MINUTES = 10

        /** PIN screen paar ho chuki hai? Screen rotate se nahi, app se bahar jane par reset hota hai. */
        @Volatile
        private var sessionOpen = false
    }

    private lateinit var gateGroup: View
    private lateinit var contentGroup: View
    private lateinit var etGatePin: EditText
    private lateinit var btnOpen: Button
    private lateinit var tvGateMsg: TextView

    private lateinit var tvStatus: TextView
    private lateinit var tvOwnerHelp: TextView
    private lateinit var tvMsg: TextView
    private lateinit var setupGroup: View
    private lateinit var actionGroup: View
    private lateinit var etNewPin: EditText
    private lateinit var etNewPin2: EditText
    private lateinit var etHost: EditText
    private lateinit var etPin: EditText
    private lateinit var btnSetPin: Button
    private lateinit var btnLock: Button
    private lateinit var btnUnlock: Button
    private lateinit var btnUpdate: Button
    private lateinit var btnRemove: Button

    private lateinit var changePinGroup: View
    private lateinit var etOldPin: EditText
    private lateinit var etChangePin: EditText
    private lateinit var etChangePin2: EditText
    private lateinit var btnChangePin: Button
    private lateinit var tvChangeMsg: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // PIN screen ka screenshot / recents preview band
        window.setFlags(
            WindowManager.LayoutParams.FLAG_SECURE,
            WindowManager.LayoutParams.FLAG_SECURE
        )
        setContentView(R.layout.activity_main)
        bindViews()
        etHost.setText(LockStore.savedHost(this))
        setupActions()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onStop() {
        super.onStop()
        // App se bahar jate hi PIN dobara maangenge (screen rotate par nahi)
        if (!isChangingConfigurations) sessionOpen = false
    }

    private fun bindViews() {
        gateGroup = findViewById(R.id.gateGroup)
        contentGroup = findViewById(R.id.contentGroup)
        etGatePin = findViewById(R.id.etGatePin)
        btnOpen = findViewById(R.id.btnOpen)
        tvGateMsg = findViewById(R.id.tvGateMsg)

        tvStatus = findViewById(R.id.tvStatus)
        tvOwnerHelp = findViewById(R.id.tvOwnerHelp)
        tvMsg = findViewById(R.id.tvMsg)
        setupGroup = findViewById(R.id.setupGroup)
        actionGroup = findViewById(R.id.actionGroup)
        etNewPin = findViewById(R.id.etNewPin)
        etNewPin2 = findViewById(R.id.etNewPin2)
        etHost = findViewById(R.id.etHost)
        etPin = findViewById(R.id.etPin)
        btnSetPin = findViewById(R.id.btnSetPin)
        btnLock = findViewById(R.id.btnLock)
        btnUnlock = findViewById(R.id.btnUnlock)
        btnUpdate = findViewById(R.id.btnUpdate)
        btnRemove = findViewById(R.id.btnRemove)

        changePinGroup = findViewById(R.id.changePinGroup)
        etOldPin = findViewById(R.id.etOldPin)
        etChangePin = findViewById(R.id.etChangePin)
        etChangePin2 = findViewById(R.id.etChangePin2)
        btnChangePin = findViewById(R.id.btnChangePin)
        tvChangeMsg = findViewById(R.id.tvChangeMsg)
    }

    private fun setupActions() {
        btnOpen.setOnClickListener { openApp() }
        etGatePin.setOnEditorActionListener { _, _, _ ->
            openApp()
            true
        }

        tvStatus.setOnLongClickListener {
            copyDebug()
            true
        }

        btnSetPin.setOnClickListener { setPin() }
        btnChangePin.setOnClickListener { changePin() }

        btnLock.setOnClickListener {
            val host = etHost.text.toString()
            withPin { Messages.lockResult(DnsLock.lock(this, host)) }
        }
        btnUnlock.setOnClickListener {
            withPin { Messages.unlockResult(DnsLock.unlock(this, UNLOCK_MINUTES), UNLOCK_MINUTES) }
        }
        btnUpdate.setOnClickListener {
            withPin { Messages.updateResult(DnsLock.allowUpdate(this, UPDATE_MINUTES), UPDATE_MINUTES) }
        }
        btnRemove.setOnClickListener {
            withPin { Messages.removeResult(DnsLock.removeOwner(this)) }
        }
    }

    /** Status box dabake rakhne par debug text clipboard me (PIN ya host jaisi koi cheez isme nahi hoti). */
    private fun copyDebug() {
        val cm = getSystemService(ClipboardManager::class.java)
        cm.setPrimaryClip(ClipData.newPlainText("pindnslock-debug", PageBlockLog.dump(this)))
        toast(Messages.DEBUG_COPIED)
    }

    /** Gate: PIN sahi ho to app khulti hai. Galat PIN / lockout ka hisaab PinStore.verify() rakhta hai. */
    private fun openApp() {
        if (!btnOpen.isEnabled) return
        val pin = etGatePin.text.toString()
        if (!PinStore.isValidFormat(pin)) {
            toast(Messages.PIN_ENTER)
            return
        }
        btnOpen.isEnabled = false
        inBackground(
            work = {
                try {
                    Messages.pinFailure(PinStore.verify(this, pin)) // null = PIN sahi
                } catch (e: Exception) {
                    Messages.errorText(e)
                }
            },
            done = { problem ->
                etGatePin.text.clear()
                btnOpen.isEnabled = true
                if (problem == null) {
                    sessionOpen = true
                    tvGateMsg.text = ""
                } else {
                    tvGateMsg.text = problem
                }
                refresh()
            }
        )
    }

    private fun setPin() {
        val a = etNewPin.text.toString()
        val b = etNewPin2.text.toString()
        val issue = PinStore.checkNew(a, b)
        if (issue != null) {
            toast(Messages.pinIssue(issue))
            return
        }
        btnSetPin.isEnabled = false
        inBackground(
            work = { PinStore.set(this, a) },
            done = {
                etNewPin.text.clear()
                etNewPin2.text.clear()
                btnSetPin.isEnabled = true
                sessionOpen = true // abhi PIN banaya hai, isliye gate ki zarurat nahi
                tvMsg.text = Messages.PIN_SET_DONE
                refresh()
            }
        )
    }

    /** Purana PIN + naya PIN (do baar). Purana PIN galat ho to kuch nahi badalta. */
    private fun changePin() {
        val old = etOldPin.text.toString()
        val a = etChangePin.text.toString()
        val b = etChangePin2.text.toString()
        val issue = PinStore.checkChange(old, a, b)
        if (issue != null) {
            toast(Messages.pinIssue(issue))
            return
        }
        btnChangePin.isEnabled = false
        inBackground(
            work = {
                try {
                    Messages.pinFailure(PinStore.change(this, old, a)) ?: Messages.PIN_CHANGED
                } catch (e: Exception) {
                    Messages.errorText(e)
                }
            },
            done = { msg ->
                etOldPin.text.clear()
                etChangePin.text.clear()
                etChangePin2.text.clear()
                btnChangePin.isEnabled = true
                tvChangeMsg.text = msg
                toast(msg)
            }
        )
    }

    /** PIN check (background) -> sahi ho to action chalao. action screen par dikhane wala text deta hai. */
    private fun withPin(action: () -> String) {
        val pin = etPin.text.toString()
        if (!PinStore.isValidFormat(pin)) {
            toast(Messages.PIN_ENTER)
            return
        }
        setBusy(true)
        inBackground(
            work = {
                try {
                    Messages.pinFailure(PinStore.verify(this, pin)) ?: action()
                } catch (e: Exception) {
                    Messages.errorText(e)
                }
            },
            done = { msg ->
                etPin.text.clear()
                setBusy(false)
                tvMsg.text = msg
                refresh()
            }
        )
    }

    /** Kaam background thread par, natija screen (UI thread) par. */
    private fun <T> inBackground(work: () -> T, done: (T) -> Unit) {
        Thread {
            val result = work()
            runOnUiThread { done(result) }
        }.start()
    }

    private fun setBusy(busy: Boolean) {
        btnLock.isEnabled = !busy
        btnUnlock.isEnabled = !busy
        btnUpdate.isEnabled = !busy
        btnRemove.isEnabled = !busy
    }

    private fun refresh() {
        // Gate ke peeche bhi chalte hain: khatam hua unlock band hoga, aur lock laga ho to poora set pakka hoga
        DnsLock.relockIfExpired(this)
        DnsLock.dropLegacyInstallBlock(this)
        DnsLock.enforceIfLocked(this)

        val pinSet = PinStore.isSet(this)
        val gated = pinSet && !sessionOpen
        gateGroup.visibility = if (gated) View.VISIBLE else View.GONE
        contentGroup.visibility = if (gated) View.GONE else View.VISIBLE
        if (gated) return

        val owner = DnsState.isOwner(this)

        tvOwnerHelp.visibility = if (owner) View.GONE else View.VISIBLE
        setupGroup.visibility = if (owner && !pinSet) View.VISIBLE else View.GONE
        actionGroup.visibility = if (owner && pinSet) View.VISIBLE else View.GONE
        changePinGroup.visibility = if (pinSet) View.VISIBLE else View.GONE

        tvStatus.text = Messages.status(
            DeviceStatus(
                owner = owner,
                dns = DnsState.currentDns(this),
                locked = DnsState.isLocked(this),
                unlockUntil = LockStore.unlockUntil(this),
                updateLocked = DnsState.isUpdateLocked(this),
                updateUntil = LockStore.updateUntil(this),
                resetBlocked = DnsState.isResetBlocked(this),
                guardOn = DnsGuard.isArmed(this),
                fastGuard = DnsGuard.isFastRunning(),
                directWrite = DnsWriter.canWriteDirect(this),
                pageBlock = PageBlock.state(this),
                appLocked = DnsState.isAppLocked(this),
                battery = DnsState.battery(this)
            )
        )
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
