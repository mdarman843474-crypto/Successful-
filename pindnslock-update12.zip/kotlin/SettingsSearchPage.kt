package com.pindnslock

import android.view.accessibility.AccessibilityNodeInfo

/**
 * Settings ka search screen pehchanna (sirf English Settings): upar search box (EditText) aur "Cancel".
 * Khali box me hint "Search settings" hota hai; likhne ke baad neeche "Couldn't find what you need? Tap to report." aata hai.
 * Dusre screens ke EditText (jaise Wi-Fi password) is signature se match nahi karte.
 */
object SettingsSearchPage {
    fun isShownIn(root: AccessibilityNodeInfo): Boolean {
        if (!PageText.hasEditText(root) || !PageText.hasExact(root, "Cancel")) return false
        return PageText.hasHintContaining(root, "search settings") ||
            !root.findAccessibilityNodeInfosByText("find what you need").isNullOrEmpty()
    }

    /** Debug ke liye: kaun si sharten sach thin. */
    fun verdict(root: AccessibilityNodeInfo): String =
        "editText=" + PageText.hasEditText(root) + " cancel=" + PageText.hasExact(root, "Cancel") +
            " hint=" + PageText.hasHintContaining(root, "search settings") +
            " report=" + !root.findAccessibilityNodeInfosByText("find what you need").isNullOrEmpty() +
            " => page=" + isShownIn(root)
}
